//
//  CalendarCollectionViewCell.swift
//  FullServiceHouseCleaning
//
//  Created by Student on 3/19/18.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit

class CalendarCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var dayButton: IDButton!
    @IBOutlet weak var cellView: UIView!
    var cellData:[String:[String:Bool]] = [:]
    func dertermineAvailability(superView: CalendarViewController)
    {
        switch superView.selectedTech! {
        case superView.tech1Button.titleLabel!.text!:
            self.dayButton.isEnabled = self.cellData["availability"]!["techOne"]!
            if self.dayButton.isEnabled == false
            {
                self.dayButton.backgroundColor = .darkGray
                
            }
            else
            {
                self.dayButton.backgroundColor = .white
            }
        case superView.tech2Button.titleLabel!.text!:
            self.dayButton.isEnabled = self.cellData["availability"]!["techTwo"]!
            if self.dayButton.isEnabled == false
            {
                self.dayButton.backgroundColor = .darkGray
            }
            else
            {
                self.dayButton.backgroundColor = .white
            }
        case superView.tech3Button.titleLabel!.text!:
            self.dayButton.isEnabled = self.cellData["availability"]!["techThree"]!
            if self.dayButton.isEnabled == false
            {
                self.dayButton.backgroundColor = .darkGray
            }
            else
            {
                self.dayButton.backgroundColor = .white
            }
        default:
            self.dayButton.isEnabled = self.cellData["availability"]!["techOne"]!
            if self.dayButton.isEnabled == false
            {
                self.dayButton.backgroundColor = .darkGray
            }
            else
            {
                self.dayButton.backgroundColor = .white
            }
        }
    }
}
