//
//  CalendarViewController.swift
//  FullServiceHouseCleaning
//
//  Created by Student on 3/19/18.
//  Copyright © 2018 Student. All rights reserved.
// connect tech selected buttons to color of all cells, trigger reload of collection?

import UIKit


class CalendarViewController: UIViewController
{
    @IBOutlet weak var monthLabel: UILabel!
    @IBOutlet weak var day1Label: UILabel!
    @IBOutlet weak var day2Label: UILabel!
    @IBOutlet weak var day3Label: UILabel!
    @IBOutlet weak var day4Label: UILabel!
    @IBOutlet weak var day5Label: UILabel!
    @IBOutlet weak var day6Label: UILabel!
    @IBOutlet weak var day7Label: UILabel!
    
    @IBOutlet weak var tech3Button: UIButton!
    @IBOutlet weak var tech2Button: UIButton!
    @IBOutlet weak var tech1Button: UIButton!
    @IBOutlet weak var currentPlanLabel: UILabel!
    @IBOutlet weak var calendarCollectionView: UICollectionView!
    
    @IBAction func tech1ButtonTapped(_ sender: Any) {
        self.selectedTech = self.tech1Button.titleLabel!.text
        calendarCollectionView.backgroundColor = tech1Button.backgroundColor
        calendarCollectionView.reloadData()
    }
    @IBAction func tech2ButtonTapped(_ sender: Any) {
        self.selectedTech = self.tech2Button.titleLabel!.text
        calendarCollectionView.backgroundColor = tech2Button.backgroundColor
        calendarCollectionView.reloadData()
    }
    @IBAction func tech3ButtonTapped(_ sender: Any) {
        self.selectedTech = self.tech3Button.titleLabel!.text
        calendarCollectionView.backgroundColor = tech3Button.backgroundColor
        calendarCollectionView.reloadData()
    }
    
    let data = Data()
    var planSelected:String! = "Timeless"
    var selectedMonth:String! = "MARCH"
    var selectedYear = "2018"
    var yearData = YearData()
    var selectedTech:String? = nil
    var monthData:[Int:[String:[String:Bool]]] = [:]
    var userAddress:String! = "123 Fake Lane, Cedar City UT"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        calendarCollectionView.delegate = self
        calendarCollectionView.dataSource = self
        currentPlanLabel.text = "Current Plan: "+planSelected
        setMonthAndDays()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setMonthAndDays()
    {
        self.monthLabel.text! = self.selectedMonth
        var day = self.yearData.month![self.selectedMonth]!["start"]
        self.day1Label.text = day
        let mute = DateMutes()
        day = mute.theDayAfter(day: day!)
        self.day2Label.text = day
        day = mute.theDayAfter(day: day!)
        self.day3Label.text = day
        day = mute.theDayAfter(day: day!)
        self.day4Label.text = day
        day = mute.theDayAfter(day: day!)
        self.day5Label.text = day
        day = mute.theDayAfter(day: day!)
        self.day6Label.text = day
        day = mute.theDayAfter(day: day!)
        self.day7Label.text = day
        self.monthData = self.data.calendarAvailability[self.yearData.number]![self.selectedMonth.uppercased()]!
    }
    func unNilTech()
    {
        if self.selectedTech == nil{
            self.tech1ButtonTapped(self)
        }
    }
    
    @objc func calendarCellButtonTapped(withSender sender:IDButton)
    {
        let day:String! = sender.ID
        var message = "You are about to schedule a "+self.planSelected+" visit on "
        message += self.selectedMonth+" "+day+", "+self.selectedYear+" from "+self.selectedTech!+" at "+self.userAddress+". Does everything look correct?"
        let alert = UIAlertController(title: "Schedule Visit?", message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Yes", style: UIAlertActionStyle.default, handler: nil))
        alert.addAction(UIAlertAction(title: "No", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension CalendarViewController: UICollectionViewDelegate, UICollectionViewDataSource
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        self.unNilTech()
        print("numberOfItemsInSection start")
        let numOfDays = self.yearData.month![self.selectedMonth.uppercased()]!["days"]
        let intOfDays: Int! = Int(numOfDays!)
        var cgHeight = CGFloat(5*75+10)
        if intOfDays == 28
        {
            cgHeight = CGFloat(4*75+10)
        }
        self.calendarCollectionView.frame = CGRect(x: self.calendarCollectionView.frame.minX, y: self.calendarCollectionView.frame.minY, width: self.calendarCollectionView.frame.width, height:cgHeight)
        return intOfDays
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "calendarCell", for: indexPath) as! CalendarCollectionViewCell
        
        cell.dayButton.setTitle(String(indexPath.row+1), for: UIControlState.normal)
        cell.cellData = self.monthData[indexPath.row+1]!
        cell.dertermineAvailability(superView:self)
        if cell.dayButton.isEnabled
        {
            cell.dayButton.ID = String(indexPath.row+1)
            cell.dayButton.addTarget(self, action: #selector(calendarCellButtonTapped(withSender:)), for: .touchUpInside)
        }
        return cell
    }
    
}

struct DateMutes {
    private let dayAfterDict_caps = [
        "MONDAY":"TUESDAY",
        "TUESDAY" :"WEDNESDAY",
        "WEDNESDAY":"THURSDAY",
        "THURSDAY":"FRIDAY",
        "FRIDAY":"SATURDAY",
        "SATURDAY":"SUNDAY",
        "SUNDAY":"MONDAY"
    ]
    private let monthStringDict_caps:[String:String] = [
        "JANUARY":"01",
        "FEBRUARY":"02",
        "MARCH":"03",
        "APRIL":"04",
        "MAY":"05",
        "JUNE":"06",
        "JULY":"07",
        "AUGUST":"08",
        "SEPTEMBER":"09",
        "OCTOBER":"10",
        "NOVEMBER":"11",
        "DECEMBER":"12"
    ]
    func theDayAfter(day:String) -> String!
    {
        return dayAfterDict_caps[day.uppercased()]
    }
    
    func convertMonthStringToInt(monthString:String!) -> String
    {
        return self.monthStringDict_caps[monthString.uppercased()]!
    }
    
}

class YearData {

    var number = 2018
    var month = MonthDataSets().year[2018]
    
    func selectNewYear(newYear: Int)
    {
        self.number = newYear
        //change month data here as appropriate. Eventually, the month var will be assigned from a private array of all the different month info for each year. It would just be reassigned, like self.month = self.monthDataSets[String(newYear)]
    }
    
    struct MonthDataSets{
        let year =
            [
                2018:[
                    "JANUARY":["start":"MONDAY",
                               "days":"31",
                               "number":"01"],
                    "FEBRUARY":["start":"THURSDAY",
                                "days":"28",
                                "number":"02"],
                    "MARCH":["start":"FRIDAY",
                             "days":"31",
                             "number":"03"],
                    "APRIL":["start":"WEDNESDAY",
                             "days":"30",
                             "number":"04"],
                    "MAY":["start":"FRIDAY",
                           "days":"31",
                           "number":"05"],
                    "JUNE":["start":"MONDAY",
                            "days":"30",
                            "number":"06"],
                    "JULY":["start":"SUNDAY",
                            "days":"31",
                            "number":"07"],
                    "AUGUST":["start":"WEDNESDAY",
                              "days":"31",
                              "number":"08"],
                    "SEPTEMBER":["start":"SATURDAY",
                                 "days":"30",
                                 "number":"09"],
                    "OCTOBER":["start":"MONDAY",
                               "days":"31",
                               "number":"10"],
                    "NOVEMBER":["start":"THURSDAY",
                                "days":"30",
                                "number":"11"],
                    "DECEMBER":["start":"SATURDAY",
                                "days":"31",
                                "number":"12"]
                ],
                2019:[
                    "JANUARY":["start":"?",
                               "days":"31",
                               "number":"01"],
                    "FEBRUARY":["start":"?",
                                "days":"28",
                                "number":"02"],
                    "MARCH":["start":"?",
                             "days":"31",
                             "number":"03"],
                    "APRIL":["start":"?",
                             "days":"30",
                             "number":"04"],
                    "MAY":["start":"?",
                           "days":"31",
                           "number":"05"],
                    "JUNE":["start":"?",
                            "days":"30",
                            "number":"06"],
                    "JULY":["start":"?",
                            "days":"31",
                            "number":"07"],
                    "AUGUST":["start":"?",
                              "days":"31",
                              "number":"08"],
                    "SEPTEMBER":["start":"?",
                                 "days":"30",
                                 "number":"09"],
                    "OCTOBER":["start":"?",
                               "days":"31",
                               "number":"10"],
                    "NOVEMBER":["start":"?",
                                "days":"30",
                                "number":"11"],
                    "DECEMBER":["start":"?",
                                "days":"31",
                                "number":"12"]
                ]
        ]
    }
}
