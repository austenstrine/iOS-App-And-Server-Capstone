//
//  PlansViewController.swift
//  FullServiceHouseCleaning
//
//  Created by Student on 3/19/18.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit

class PlansViewController: UIViewController {

    @IBOutlet weak var planImage: UIImageView!
    @IBOutlet weak var planContentLabel: UILabel!
    @IBOutlet weak var planRateLabel: UILabel!
    @IBOutlet weak var planTitleLabel: UILabel!
    let data = Data()
    var planSelected:String! = Data().selectedPlan["timeless"]!["title"]
    @IBAction func goldPlanNavTap(_ sender: Any) {
        planSelected = data.selectedPlan["gold"]!["title"]
        updatePlanContent()
    }
    @IBAction func silverPlanNavTap(_ sender: Any) {
        planSelected = data.selectedPlan["silver"]!["title"]
        updatePlanContent()
    }
    @IBAction func bronzePlanNavTap(_ sender: Any) {
        planSelected = data.selectedPlan["bronze"]!["title"]
        updatePlanContent()
    }
    @IBAction func timelessPlanNavTap(_ sender: Any) {
        planSelected = data.selectedPlan["timeless"]!["title"]
        updatePlanContent()
    }
    @IBAction func tapPlanSelectButton(_ sender: Any) {
        let myVC = storyboard!.instantiateViewController(withIdentifier: "CalendarViewController") as! CalendarViewController
        myVC.planSelected = planSelected
        navigationController?.pushViewController(myVC, animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        updatePlanContent()
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func updatePlanContent()
    {
        switch self.planSelected {
        case self.data.selectedPlan["gold"]!["title"]!:
            self.planImage.image = UIImage(named:self.data.selectedPlan["gold"]!["image"]!)
            self.planTitleLabel.text = self.data.selectedPlan["gold"]!["title"]!
            self.planRateLabel.text = self.data.selectedPlan["gold"]!["rate"]!
            self.planContentLabel.text = self.data.selectedPlan["gold"]!["description"]!
        case self.data.selectedPlan["silver"]!["title"]!:
            self.planImage.image = UIImage(named:self.data.selectedPlan["silver"]!["image"]!)
            self.planTitleLabel.text = self.data.selectedPlan["silver"]!["title"]!
            self.planRateLabel.text = self.data.selectedPlan["silver"]!["rate"]!
            self.planContentLabel.text = self.data.selectedPlan["silver"]!["description"]!
        case self.data.selectedPlan["bronze"]!["title"]!:
            self.planImage.image = UIImage(named:self.data.selectedPlan["bronze"]!["image"]!)
            self.planTitleLabel.text = self.data.selectedPlan["bronze"]!["title"]!
            self.planRateLabel.text = self.data.selectedPlan["bronze"]!["rate"]!
            self.planContentLabel.text = self.data.selectedPlan["bronze"]!["description"]!
        case self.data.selectedPlan["timeless"]!["title"]!:
            self.planImage.image = UIImage(named:self.data.selectedPlan["timeless"]!["image"]!)
            self.planTitleLabel.text = self.data.selectedPlan["timeless"]!["title"]!
            self.planRateLabel.text = self.data.selectedPlan["timeless"]!["rate"]!
            self.planContentLabel.text = self.data.selectedPlan["timeless"]!["description"]!
        default:
            print("Whoops! What happened? Unexpected planSelected value!")
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
