//
//  IDButton.swift
//  FullServiceHouseCleaning
//
//  Created by Student on 3/20/18.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit

class IDButton: UIButton {
    
    var ID:String? = ""

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
